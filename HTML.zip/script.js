document.addEventListener('DOMContentLoaded', () => {
    console.log('Welcome to Food Recipes!');
});
